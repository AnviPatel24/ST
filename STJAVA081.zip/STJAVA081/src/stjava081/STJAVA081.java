/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package stjava081;

import java.util.ArrayList;

/**
 *
 * @author hadoop
 */
public class STJAVA081 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       // System.out.println(calculate(5,7));
    }
    
    public static int multiply(int a,int b , int c)
    {
        return a*b*c;
    }
    
    public static boolean check(String a, String b)        
    {
      if(a.equals(b))
      {
          if(a.length()==b.length())
          {
            return true;
          }
          
          else
            {
                return false;
            }
      }
      else
      {
          return false;
      }
      
    }
    
    
    // IMplement a java program to count a number of alphabet in the given string and 
   // perform unit testing using JUNIT.
    
    public static int countalpha(String a)
    {
   
        return a.length();
    }
    
    //Implement a java program to concate the given string array into one with overlapping
    // array elements included twice.
    
    public static ArrayList<String> concatestring(String[] a, String[] b){
        ArrayList<String> mainstring = new ArrayList<String>();
           for(int i=0;i<a.length;i++)
           {
               for(int j=0;j<b.length;j++){
                   if(a[i].equals(b[j])){
                      mainstring.add(a[i]);
                   }
                   else{
                       if(mainstring.get(i).equals(a[i]))
                       {
                          // mainstring.add(a[i])==false;
                       }else{
                       mainstring.add(a[i]);
                       mainstring.add(b[j]);
                       }
                   }
               }
           }
                 
        return mainstring;
    }
    public static int calculate(int a,int b)
    {
        return a+b;
    }
    
}
