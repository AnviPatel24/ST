/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stjava081;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import java.util.ArrayList;
import static org.junit.Assert.*;

/**
 *
 * @author hadoop
 */
public class STJAVA081Test {
    
    public STJAVA081Test() {
    }
    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }

    /**
     * Test of main method, of class STJAVA081.
     */
    @Test
    public void testMain() {
//        System.out.println("main");
//        String[] args = null;
//        STJAVA081.main(args);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of calculate method, of class STJAVA081.
     */
    @Test
    public void testCalculate() {
     STJAVA081 st=new STJAVA081();
      int actualoutput= st.calculate(7,7);
      //System.out.println(actualoutput);
      int expoutput=14;
     // System.out.println(expoutput);
      assertEquals(expoutput, actualoutput);
      
    }
      
       
    
    @Test
    public void testconcatestring(){
          STJAVA081 st=new STJAVA081();
          String[] arr1={"Hello" , "Anvi"};
          String[] arr2={"Hello", "Dhyan"};
          ArrayList<String> acoutput=st.concatestring(arr1, arr2);
          ArrayList<String> expoutput=new ArrayList<String>();
          expoutput.add("Hello");
           expoutput.add("Anvi");
            expoutput.add("Dhyan");
          assertEquals(acoutput,expoutput);
    }
    @Test
    public void check(){
        STJAVA081 st=new STJAVA081();
        boolean acoutput=st.check("Anvi","Dhyan");
        boolean expoutput=false;
        assertEquals(acoutput,expoutput);
    }
    
    @Test
    public void testcountalpha(){
        STJAVA081 st=new STJAVA081();
        int count=st.countalpha("Dhyan");
        int testcount=5;
        assertEquals(count,testcount);
    }
    
    @Test
    public void testmultiply(){
         STJAVA081 st=new STJAVA081();
      int actualoutput= st.multiply(3,3,7);
      int expoutput=63;
      assertEquals(expoutput,actualoutput);
    }
    
}
